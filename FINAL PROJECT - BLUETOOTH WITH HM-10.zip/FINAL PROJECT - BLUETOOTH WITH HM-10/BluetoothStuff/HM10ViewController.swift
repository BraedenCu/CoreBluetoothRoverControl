
import UIKit
import CoreBluetooth
 
//globally accessable variables, :O
let HM10CBUUID = CBUUID(string: "0xFFE0")
var device: CBPeripheral?
var characteristic: CBCharacteristic?
 
class HM10ViewController: UIViewController {
  
  
  @IBOutlet weak var speedLabel: UILabel!
  @IBOutlet weak var timeLabel: UILabel!
  @IBOutlet weak var EpicSliderView: UIView!
  @IBOutlet weak var EpicSliderViewTwo: UIView!
  //defining bluetooth charictaristics
  var centralManager: CBCentralManager!
  var HM10: CBPeripheral!
  var positionCharacteristic: CBCharacteristic?
  var device: CBPeripheral?
  var characteristics: [CBCharacteristic]?
  var time = 0
  var sliderControl = false
  var textControl = false
  var maxSpeed: Double = 1
  var counter = 0
  var timer = Timer()
  var rss = NSNumber(-45)

  //rotate slider one and two 90 degrees
  @IBOutlet var EpicSlider: UISlider!{
    didSet{
      EpicSlider.transform = CGAffineTransform(rotationAngle: CGFloat(-M_PI_2))
    }
  }
  
  @IBOutlet weak var EpicSliderTwo: UISlider!{
    didSet{
      EpicSliderTwo.transform = CGAffineTransform(rotationAngle: CGFloat(-M_PI_2))
    }
  }
  override func viewDidLoad() {
    super.viewDidLoad()
    //initialize timer once view loads.
    centralManager = CBCentralManager(delegate: self, queue: nil)
    var timeAfterCal = time * 60
    speedLabel.text = "\(maxSpeed) power"
    timeLabel.text = "\(timeAfterCal)"
  }
  //attempt at making something run in the background
  func background(work: @escaping () -> ()) {
      DispatchQueue.global(qos: .userInitiated).async {
          work()
      }
  }
 
  @IBAction func ValueChanged(_ sender: Any) {
    //getting centerpoint of slider and putting the gray view on it for both sliders
    let trackRectSliderOne =  self.EpicSlider.trackRect(forBounds: self.EpicSlider.bounds)
    let thumbRectSliderOne = self.EpicSlider.thumbRect(forBounds: self.EpicSlider.bounds, trackRect: trackRectSliderOne, value: self.EpicSlider.value)
    EpicSliderView.center = CGPoint(x: thumbRectSliderOne.origin.x + self.EpicSlider.frame.origin.x + 30, y: self.EpicSlider.frame.origin.y - 60)
    let trackRectSliderTwo =  self.EpicSliderTwo.trackRect(forBounds: self.EpicSliderTwo.bounds)
    let thumbRectSliderTwo = self.EpicSliderTwo.thumbRect(forBounds: self.EpicSliderTwo.bounds, trackRect: trackRectSliderTwo, value: self.EpicSlider.value)
    EpicSliderViewTwo.center = CGPoint(x: thumbRectSliderTwo.origin.x + self.EpicSliderTwo.frame.origin.x + 30, y: self.EpicSliderTwo.frame.origin.y - 60)
    //sending data from first slider
    let sliderVal: Float = Float(maxSpeed) / EpicSlider!.value
    var value: UInt8 = 1
    var sliderValue: String = String(sliderVal)
    var dataa = sliderValue.data(using: String.Encoding.utf8)
    //send data to bluetooth device
    device?.writeValue(dataa as! Data, for: characteristic!, type: CBCharacteristicWriteType.withoutResponse)
    print("Sending, \(dataa)")
    
  }
  @IBAction func ValueChangedTwo(_ sender: Any) {
    //sending data from second slider
    let sliderValTwo: Float = Float(maxSpeed) / EpicSliderTwo!.value
    var sliderValueTwo: String = String(sliderValTwo)
    //send data to bluetooth device
    var data = sliderValueTwo.data(using: String.Encoding.utf8)
    device?.writeValue(data as! Data, for: characteristic!, type: CBCharacteristicWriteType.withoutResponse)
    print("Sending, \(data)")
  }
  
        
}

 
extension HM10ViewController: CBCentralManagerDelegate {
  func centralManagerDidUpdateState(_ central: CBCentralManager) {
    switch central.state {
    case .unknown:
      print("central.state is .unknown, try connecting to a different periphereal")
    case .resetting:
      print("central.state is .resetting, try again")
    case .unsupported:
      print("central.state is .unsupported, try connecting to a different periphereal")
    case .unauthorized:
      print("central.state is .unauthorized, try again")
    case .poweredOff:
      print("central.state is .poweredOff :(")
    case .poweredOn:
      print("central.state is .poweredOn")
      print("aight bet imma scan")
      
      var a: String = "DSD TECH"
      let dsd = NSData(bytes: &a, length: MemoryLayout<UInt8>.size)
      let ppp = String(data: dsd as Data, encoding: .utf8)
   centralManager.scanForPeripherals(withServices: [HM10CBUUID])
   print(centralManager.scanForPeripherals(withServices: nil))
  
    }
  }
  
  //if peripheral is discovered, connect and stop scanning for other peripherals
  func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral,
                      advertisementData: [String : Any], rssi RSSI: NSNumber) {
    print(peripheral)
    HM10 = peripheral
    HM10.delegate = self as CBPeripheralDelegate
    centralManager.stopScan()
    centralManager.connect(HM10)
    print("Connected!")
  }
  
  func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
    print("Connected!")
    //Send data to the HM10 bluetooth module using utf8 encoding
    HM10.discoverServices([HM10CBUUID])
    //RUN THIS IF CONNECTED TO A PERIPHIAL
    //let sliderVal: Float = EpicSlider!.value
    //var value: utf8 = 1
    //var sliderValue: utf8 = utf8(Int(sliderVal))
    //send data to bluetooth device
    //let data = NSData(bytes: &sliderValue, length: MemoryLayout<UInt8>.size)
    //device?.writeValue(data as Data, for: characteristic!, type: CBCharacteristicWriteType.withoutResponse)
    //print(data)
    //print(sliderVal)
  }
}
 
extension HM10ViewController: CBPeripheralDelegate {
  func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
    print("connection error")
    guard let services = peripheral.services else { return }
    for service in services {
      print(service)
      peripheral.discoverCharacteristics(nil, for: service)
    }
  }
  
  func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
    print("connected, collect peripheral charicatistics if deemed necessary")
  }
}

