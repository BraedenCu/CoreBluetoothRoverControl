
import UIKit

class ViewControllerOne: UIViewController {
  
  @IBOutlet weak var segmentedControlForMaxSpeed: UISegmentedControl!
  @IBOutlet weak var segmentedControl: UISegmentedControl!
  
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
  
  var time = 2
  var maxSpeed: Double = 0.10
  var sliderForControl = false
  var textForControl = false
  
  
  @IBAction func timeLimit(_ sender: Any) {
    switch segmentedControl.selectedSegmentIndex
      {
        case 0:
          time = 3
        case 1:
          time = 5
        case 2:
          time = 10
      default:
          break
      }
  }
  
  @IBAction func maxSpeed(_ sender: Any) {
    switch segmentedControlForMaxSpeed.selectedSegmentIndex {
    case 0:
      maxSpeed = 0.10
    case 1:
      maxSpeed = 0.30
    case 2:
      maxSpeed = 0.60
    case 3:
      maxSpeed = 1
    default:
      break
    }
  }

  @IBAction func textControl(_ sender: Any) {
    textForControl = true
    performSegue(withIdentifier: "ViewControllerOneData", sender: (Any).self)
  }
  @IBAction func sliderControl(_ sender: Any) {
    sliderForControl = true
    performSegue(withIdentifier: "ViewControllerOneData", sender: (Any).self)
  }
  
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      let destination = segue.destination as! HM10ViewController
      destination.maxSpeed = Double(maxSpeed)
      destination.time = Int(time)
      destination.sliderControl = sliderForControl
      destination.textControl = textForControl
    }
    
}
